# plugins/writer_plugins/__init__.py

# (No built-in writers yet, but when you add one, import it here.)
__all__ = []
